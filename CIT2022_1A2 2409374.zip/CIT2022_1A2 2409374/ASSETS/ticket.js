let name = sessionStorage.getItem("fullName");
let email = sessionStorage.getItem("email");
let github = sessionStorage.getItem("github");
let avatar = sessionStorage.getItem("avatar");
if (!name || !email || !github || !avatar) {
    window.location.href = "index.html";
}
else {
    document.getElementById("TicketName").textContent = name;
    document.getElementById("TicketEmail").textContent = email;
    document.getElementById("TicketAvatar").src = avatar;
    let username = github.replace(/^@/, "");

    let githubLink = document.getElementById("TicketGithub");
    githubLink.textContent = github;
    githubLink.href = "https://github.com/" + username;
    let ticketNumber = sessionStorage.getItem("TicketNumber");

    if (!ticketNumber) {
        let number = Math.floor(Math.random() * 9000) + 1000;
        ticketNumber = "CC-" + number;
        sessionStorage.setItem("TicketNumber", ticketNumber);
    }

    document.getElementById("TicketNumber").textContent = ticketNumber;
}
